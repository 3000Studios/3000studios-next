import { NavRoute } from './types';

export const DEFAULT_VIDEO_URL = "https://res.cloudinary.com/dj92eb97f/video/upload/v1767037191/blue_block_text_mm1www.mp4";

export const NAV_LINKS: NavRoute[] = [
  {
    label: "Home",
    href: "/",
  },
  {
    label: "Store",
    href: "https://3000-studios.myshopify.com/",
    isExternal: true,
    subRoutes: [
      {
        label: "3000 Store",
        href: "https://3000-studios.myshopify.com/",
        isExternal: true
      }
    ]
  },
  {
    label: "Projects",
    href: "/projects",
    subRoutes: [
      {
        label: "Ready Apps",
        href: "/projects/ready-apps"
      },
      {
        label: "In Progress",
        href: "/projects/in-progress"
      }
    ]
  },
  {
    label: "Live",
    href: "/live",
    subRoutes: [
      {
        label: "Live Stream",
        href: "/live"
      },
      {
        label: "Past Live Streams",
        href: "/live/past-streams"
      }
    ]
  },
  {
    label: "Posts",
    href: "/posts",
    subRoutes: [
      {
        label: "Today’s Posts",
        href: "/posts/todays-posts"
      },
      {
        label: "Past Posts",
        href: "/posts/past-posts"
      }
    ]
  },
  {
    label: "Admin",
    href: "/admin"
    // No sub-routes for Admin as per requirements
  }
];