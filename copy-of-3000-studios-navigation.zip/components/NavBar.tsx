import React, { useState, useEffect, useRef, useCallback } from 'react';
import { NavBarProps, NavRoute } from '../types';
import { NAV_LINKS, DEFAULT_VIDEO_URL } from '../constants';

// --- Constants for Game Logic ---
const TILE_COUNT = 10;
const RUNNER_SPEED = 0.3; // % per frame
const RUNNER_COUNT = 4;
const GRAVITY = 0.8;
const INITIAL_FALL_VY = 5;

interface RunnerState {
  id: number;
  x: number; // Percentage 0-100+
  y: number; // Pixel offset from top of nav
  vy: number; // Vertical velocity
  status: 'running-top' | 'falling' | 'running-bottom' | 'resetting';
  variant: 'gold' | 'silver' | 'bronze';
  scale: number;
}

/**
 * NavBar Component
 */
const NavBar: React.FC<NavBarProps> = ({ 
  backgroundVideoUrl = DEFAULT_VIDEO_URL,
  className = ""
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeMobileDropdown, setActiveMobileDropdown] = useState<string | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  // Game State
  const [runners, setRunners] = useState<RunnerState[]>([]);
  const requestRef = useRef<number>(0);
  const navHeight = 96; // 24 * 4 = 96px (h-24)
  const windowHeightRef = useRef(1000); // Default, updated in effect

  // Initialize Runners
  useEffect(() => {
    windowHeightRef.current = window.innerHeight;
    
    const initialRunners: RunnerState[] = Array.from({ length: RUNNER_COUNT }).map((_, i) => ({
      id: i,
      x: -10 - (i * 30), // Stagger start positions
      y: 0, // Relative to running container
      vy: 0,
      status: 'running-top',
      variant: i % 2 === 0 ? 'gold' : 'silver',
      scale: 0.8 + Math.random() * 0.4
    }));
    setRunners(initialRunners);
  }, []);

  // Game Loop
  const animate = useCallback(() => {
    setRunners(prevRunners => {
      return prevRunners.map(runner => {
        let newX = runner.x;
        let newY = runner.y;
        let newVy = runner.vy;
        let newStatus = runner.status;

        if (runner.status === 'running-top') {
          newX += RUNNER_SPEED;
          // Loop back if it goes off screen without falling
          if (newX > 110) newX = -10;
        } 
        else if (runner.status === 'falling') {
          // Physics: Gravity
          newVy += GRAVITY;
          newY += newVy;

          // Check if hit bottom of screen
          if (newY >= windowHeightRef.current - navHeight - 20) { // -20 for floor buffer
             newY = windowHeightRef.current - navHeight - 20;
             newVy = 0;
             newStatus = 'running-bottom';
          }
        } 
        else if (runner.status === 'running-bottom') {
          newX += RUNNER_SPEED * 1.5; // Run faster at bottom
          if (newX > 120) {
            // Reset to top
            newStatus = 'running-top';
            newX = -20;
            newY = 0;
            newVy = 0;
          }
        }

        return { ...runner, x: newX, y: newY, vy: newVy, status: newStatus };
      });
    });
    requestRef.current = requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(requestRef.current);
  }, [animate]);

  // Handle Tile Click (Trapdoor)
  const handleTileClick = (index: number) => {
    playTickSound();
    
    // Calculate range of this tile in percentage (0-100)
    const tileWidth = 100 / TILE_COUNT;
    const startX = index * tileWidth;
    const endX = startX + tileWidth;

    setRunners(prev => prev.map(runner => {
      // If runner is on top and within the tile's horizontal range
      if (runner.status === 'running-top' && runner.x + 2 > startX && runner.x < endX) { // +2 adjusts for center of runner
        // Push down immediately
        return { ...runner, status: 'falling', vy: INITIAL_FALL_VY };
      }
      return runner;
    }));
  };

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Ensure video plays on mount
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(error => {
        console.warn("Video autoplay failed:", error);
      });
    }
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
    setActiveMobileDropdown(null);
  };

  const toggleMobileDropdown = (label: string) => {
    setActiveMobileDropdown(prev => prev === label ? null : label);
  };

  const playTickSound = () => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } catch (e) {
      console.warn("Audio play failed", e);
    }
  };

  return (
    <nav 
      className={`relative w-full z-50 transition-all duration-300 ${className} ${isScrolled ? 'shadow-lg' : ''}`}
      aria-label="Main Navigation"
    >
      {/* Video Background Layer */}
      <div className="absolute inset-0 w-full h-full overflow-hidden z-0 bg-black">
        <video
          ref={videoRef}
          className="w-full h-full object-cover opacity-80"
          src={backgroundVideoUrl}
          autoPlay
          loop
          muted
          playsInline
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/40" />
      </div>

      {/* --- GAME LAYER: RUNNERS --- */}
      <div className="absolute inset-0 z-20 overflow-visible pointer-events-none h-24">
        {runners.map(runner => (
          <div 
            key={runner.id}
            className="absolute top-0 will-change-transform"
            style={{ 
              left: `${runner.x}%`,
              transform: `translateY(${runner.y}px) scale(${runner.scale})`,
              transition: runner.status === 'falling' ? 'none' : 'transform 0.1s linear'
            }}
          >
             {/* The 3D Mannequin */}
             <div className="relative">
               <Runner3D variant={runner.variant} status={runner.status} />
             </div>
          </div>
        ))}
      </div>

      {/* --- GAME LAYER: BRIDGE TILES --- */}
      <div className="absolute bottom-0 left-0 w-full h-6 z-40 flex pointer-events-auto">
        {Array.from({ length: TILE_COUNT }).map((_, i) => (
          <button
            key={i}
            onClick={() => handleTileClick(i)}
            className="flex-1 border-r border-white/10 hover:bg-yellow-500/30 active:bg-red-500/50 transition-colors group relative"
            title="Click to trap runners!"
          >
            {/* Tile Floor Visual */}
            <div className="absolute inset-x-1 bottom-0 h-1 bg-white/20 group-hover:bg-yellow-400/50 shadow-[0_0_10px_rgba(0,0,0,0.5)]"></div>
          </button>
        ))}
      </div>


      {/* Navigation Content */}
      <div className="relative z-30 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pointer-events-none">
        <div className="flex items-center justify-between h-24 pointer-events-auto">
          
          {/* Logo / Brand - Pure CSS 3D Animation */}
          <div className="flex-shrink-0 flex items-center perspective-1000">
            <a 
              href="/" 
              onClick={playTickSound}
              className="block relative group w-40 h-24 flex items-center justify-center animate-float"
              style={{ perspective: '1000px' }}
            >
              <div 
                className="relative flex items-center justify-center animate-spin-3d" 
                style={{ transformStyle: 'preserve-3d' }}
              >
                {/* 3000 Block - Georgia Font */}
                <div className="relative" style={{ transform: 'translateY(-10px)' }}>
                   <span className="absolute font-georgia text-4xl text-yellow-700" style={{ transform: 'translateZ(-4px)' }}>3000</span>
                   <span className="absolute font-georgia text-4xl text-yellow-600" style={{ transform: 'translateZ(-2px)' }}>3000</span>
                   <span className="absolute font-georgia text-4xl text-yellow-500" style={{ transform: 'translateZ(0px)' }}>3000</span>
                   <span className="absolute font-georgia text-4xl text-yellow-400 drop-shadow-[0_0_8px_rgba(255,215,0,0.6)]" style={{ transform: 'translateZ(2px)' }}>3000</span>
                   {/* Backside 3000 */}
                   <span className="absolute font-georgia text-4xl text-yellow-700" style={{ transform: 'rotateY(180deg) translateZ(4px)' }}>3000</span>
                   <span className="absolute font-georgia text-4xl text-yellow-400" style={{ transform: 'rotateY(180deg) translateZ(0px)' }}>3000</span>
                </div>

                {/* Studios Block - Below 3000 - Georgia Font */}
                <div className="absolute top-8 w-40 text-center" style={{ transformStyle: 'preserve-3d' }}>
                    <div className="relative inline-block" style={{ transform: 'translateZ(10px)' }}>
                        <span className="block font-georgia text-lg tracking-[0.1em] font-bold text-white bg-black/60 px-2 py-0.5 rounded border border-yellow-500/30 backdrop-blur-sm">Studios</span>
                    </div>
                    {/* Backside Studios */}
                    <div className="absolute top-0 left-0 w-full flex justify-center" style={{ transform: 'rotateY(180deg) translateZ(10px)' }}>
                        <span className="block font-georgia text-lg tracking-[0.1em] font-bold text-white bg-black/60 px-2 py-0.5 rounded border border-yellow-500/30 backdrop-blur-sm">Studios</span>
                    </div>
                </div>
              </div>
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-10 items-center">
            {NAV_LINKS.map((link) => (
              <DesktopNavItem key={link.label} route={link} playSound={playTickSound} />
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden pointer-events-auto">
            <button
              onClick={() => { toggleMobileMenu(); playTickSound(); }}
              type="button"
              className="text-gray-200 hover:text-white focus:outline-none focus:ring-2 focus:ring-white p-2 rounded-md transition-colors"
              aria-controls="mobile-menu"
              aria-expanded={isMobileMenuOpen}
            >
              <span className="sr-only">Open main menu</span>
              {isMobileMenuOpen ? (
                <svg className="h-8 w-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="h-8 w-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <div 
        className={`md:hidden relative z-50 bg-black/95 backdrop-blur-md overflow-hidden transition-[max-height,opacity] duration-300 ease-in-out ${isMobileMenuOpen ? 'max-h-screen opacity-100 border-t border-gray-800' : 'max-h-0 opacity-0'}`}
        id="mobile-menu"
      >
        <div className="px-2 pt-2 pb-6 space-y-1">
          {NAV_LINKS.map((link) => (
            <MobileNavItem 
              key={link.label} 
              route={link} 
              isOpen={activeMobileDropdown === link.label}
              onToggle={() => { toggleMobileDropdown(link.label); playTickSound(); }}
              closeMenu={() => setIsMobileMenuOpen(false)}
              playSound={playTickSound}
            />
          ))}
        </div>
      </div>
    </nav>
  );
};

// --- Sub-Components ---

/**
 * Runner3D Component
 * A CSS-constructed 3D mannequin with running animations
 */
const Runner3D: React.FC<{ variant: 'gold' | 'silver' | 'bronze'; status: string }> = ({ variant, status }) => {
  // Colors based on variant
  const headColor = variant === 'gold' ? 'bg-yellow-300' : 'bg-gray-300';
  const bodyColor = variant === 'gold' ? 'bg-yellow-600' : 'bg-gray-500';
  const limbColor = variant === 'gold' ? 'bg-yellow-500' : 'bg-gray-400';
  
  const isFalling = status === 'falling';

  // Styles for falling vs running
  const leftArmClass = isFalling 
    ? "origin-top transition-transform duration-300 -rotate-[160deg]" // Flail up
    : "origin-top limb-swing-left"; 
    
  const rightArmClass = isFalling
    ? "origin-top transition-transform duration-300 rotate-[160deg]" // Flail up
    : "origin-top limb-swing-right";

  const leftLegClass = isFalling
    ? "origin-top transition-transform duration-300 rotate-[10deg]" // Dangle
    : "origin-top leg-swing-left";

  const rightLegClass = isFalling
    ? "origin-top transition-transform duration-300 -rotate-[10deg]" // Dangle
    : "origin-top leg-swing-right";

  return (
    <div className="relative w-8 h-16 pointer-events-none" style={{ transformStyle: 'preserve-3d' }}>
      {/* Head */}
      <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full ${headColor} shadow-sm z-20`} />
      
      {/* Torso */}
      <div className={`absolute top-3 left-1/2 -translate-x-1/2 w-4 h-6 ${bodyColor} rounded-sm z-10`} />

      {/* Left Arm (Shoulder Pivot) */}
      <div className={`absolute top-3 left-0 w-1.5 h-6 ${leftArmClass}`}>
        <div className={`w-full h-4 ${limbColor} rounded-full`} /> {/* Upper Arm */}
        <div className={`w-full h-3 ${limbColor} mt-[-2px] rounded-full opacity-90`} /> {/* Forearm */}
        <div className={`w-2 h-2 ${headColor} rounded-full mt-[-2px] -ml-[1px]`} /> {/* Hand */}
      </div>

      {/* Right Arm (Shoulder Pivot) */}
      <div className={`absolute top-3 right-0 w-1.5 h-6 ${rightArmClass}`}>
        <div className={`w-full h-4 ${limbColor} rounded-full`} />
        <div className={`w-full h-3 ${limbColor} mt-[-2px] rounded-full opacity-90`} />
        <div className={`w-2 h-2 ${headColor} rounded-full mt-[-2px] -ml-[1px]`} />
      </div>

      {/* Left Leg (Hip Pivot) */}
      <div className={`absolute top-8 left-1 w-1.5 h-7 ${leftLegClass}`}>
        <div className={`w-full h-4 ${limbColor} rounded-full`} /> {/* Thigh */}
        <div className={`w-full h-4 ${limbColor} mt-[-2px] rounded-full opacity-90`} /> {/* Calf */}
        <div className={`w-3 h-1.5 ${bodyColor} mt-[-1px] -ml-[1px] rounded-sm`} /> {/* Foot */}
      </div>

      {/* Right Leg (Hip Pivot) */}
      <div className={`absolute top-8 right-1 w-1.5 h-7 ${rightLegClass}`}>
        <div className={`w-full h-4 ${limbColor} rounded-full`} />
        <div className={`w-full h-4 ${limbColor} mt-[-2px] rounded-full opacity-90`} />
        <div className={`w-3 h-1.5 ${bodyColor} mt-[-1px] -ml-[1px] rounded-sm`} />
      </div>
    </div>
  );
};


/**
 * Desktop Nav Item
 */
const DesktopNavItem: React.FC<{ route: NavRoute; playSound: () => void }> = ({ route, playSound }) => {
  const hasSubRoutes = route.subRoutes && route.subRoutes.length > 0;

  return (
    <div className="relative group pointer-events-auto">
      <a
        href={route.href}
        onClick={playSound}
        className="
          font-gugi text-lg px-3 py-2 tracking-wider transition-all duration-300 relative flex items-center gap-1
          text-gray-100 
          hover:text-transparent hover:bg-clip-text 
          hover:bg-gradient-to-r hover:from-[#C5A059] hover:via-[#FFFFFF] hover:to-[#C5A059]
          hover:bg-[length:200%_auto] hover:animate-shimmer
          hover:scale-110 drop-shadow-md hover:drop-shadow-[0_0_8px_rgba(255,215,0,0.5)]
        "
        target={route.isExternal ? "_blank" : undefined}
        rel={route.isExternal ? "noopener noreferrer" : undefined}
      >
        {route.label}
        {hasSubRoutes && (
          // Carrot Arrow: Rotates 360 deg on hover to point down again (spin)
          <svg className="w-4 h-4 opacity-70 group-hover:opacity-100 transition-transform duration-500 group-hover:rotate-[360deg] text-gray-300 group-hover:text-[#FFD700]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        )}
        <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-transparent via-[#FFD700] to-transparent bg-[length:200%_auto] animate-shimmer transition-all duration-300 ease-out group-hover:w-full box-shadow-[0_0_8px_rgba(255,215,0,0.8)]"></span>
      </a>

      {hasSubRoutes && (
        <div className="absolute left-0 mt-4 w-64 opacity-0 translate-y-2 invisible group-hover:opacity-100 group-hover:translate-y-0 group-hover:visible transition-all duration-200 ease-out transform origin-top-left z-50">
          <div className="rounded-md shadow-xl ring-1 ring-black ring-opacity-5 overflow-hidden bg-gray-900/95 backdrop-blur-md border border-gray-700">
            <div className="py-2" role="menu" aria-orientation="vertical">
              {route.subRoutes?.map((sub) => (
                <a
                  key={sub.href}
                  href={sub.href}
                  onClick={playSound}
                  className="block px-6 py-4 text-base font-gugi text-gray-300 hover:bg-white/10 hover:text-[#FFD700] transition-colors border-l-2 border-transparent hover:border-[#FFD700]"
                  role="menuitem"
                  target={sub.isExternal ? "_blank" : undefined}
                  rel={sub.isExternal ? "noopener noreferrer" : undefined}
                >
                  {sub.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * Mobile Nav Item
 */
const MobileNavItem: React.FC<{ 
  route: NavRoute; 
  isOpen: boolean; 
  onToggle: () => void;
  closeMenu: () => void;
  playSound: () => void;
}> = ({ route, isOpen, onToggle, closeMenu, playSound }) => {
  const hasSubRoutes = route.subRoutes && route.subRoutes.length > 0;
  const handleClick = (e: React.MouseEvent) => {
    playSound();
    if (hasSubRoutes) {
      e.preventDefault();
      onToggle();
    } else {
      closeMenu();
    }
  };

  return (
    <div className="border-b border-gray-800 last:border-0 pointer-events-auto">
      <div className="flex items-center justify-between">
        <a
          href={route.href}
          className="flex-grow block px-4 py-5 text-xl font-gugi text-gray-100 hover:text-[#FFD700] hover:bg-white/5 rounded-md transition-colors"
          onClick={handleClick}
          target={route.isExternal && !hasSubRoutes ? "_blank" : undefined}
          rel={route.isExternal && !hasSubRoutes ? "noopener noreferrer" : undefined}
        >
          {route.label}
        </a>
        {hasSubRoutes && (
          <button 
            onClick={() => { onToggle(); playSound(); }}
            className="p-5 text-gray-400 hover:text-[#FFD700] focus:outline-none"
          >
            <svg 
              className={`w-6 h-6 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
        )}
      </div>

      {hasSubRoutes && (
        <div 
          className={`overflow-hidden transition-all duration-300 ease-in-out bg-black/40 ${isOpen ? 'max-h-72 opacity-100' : 'max-h-0 opacity-0'}`}
        >
          {route.subRoutes?.map((sub) => (
            <a
              key={sub.href}
              href={sub.href}
              className="block pl-10 pr-4 py-4 text-base font-gugi text-gray-400 hover:text-[#FFD700] hover:bg-white/5 border-l-4 border-transparent hover:border-[#FFD700] transition-colors"
              onClick={() => { closeMenu(); playSound(); }}
              target={sub.isExternal ? "_blank" : undefined}
              rel={sub.isExternal ? "noopener noreferrer" : undefined}
            >
              {sub.label}
            </a>
          ))}
        </div>
      )}
    </div>
  );
};

export default NavBar;