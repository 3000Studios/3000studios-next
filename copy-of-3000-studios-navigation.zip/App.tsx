import React from 'react';
import NavBar from './components/NavBar';

const App = () => {
  return (
    <div className="min-h-screen bg-gray-900 font-sans text-white">
      {/* 
        This is a container for the NavBar. 
        It demonstrates the transparency and video background capabilities.
      */}
      <div className="relative">
        <NavBar />
        
        {/* 
          Hero Section Content 
          This sits 'underneath' visually if the navbar was sticky/fixed, 
          but here it flows naturally.
        */}
        <header className="relative w-full h-[600px] flex items-center justify-center overflow-hidden">
          {/* Background image for hero section to contrast with nav video */}
          <div className="absolute inset-0 z-0">
             <img 
               src="https://picsum.photos/1920/1080?grayscale&blur=2" 
               alt="Background" 
               className="w-full h-full object-cover opacity-30" 
             />
             <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
          </div>
          
          <div className="relative z-10 text-center px-4">
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 animate-fade-in-up">
              CREATIVITY <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
                UNLEASHED
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-2xl mx-auto mb-10">
              Navigation component ready for Next.js App Router.
              <br />
              <span className="text-sm opacity-60 mt-2 block">
                (Resize window to test responsiveness)
              </span>
            </p>
            <div className="flex gap-4 justify-center">
              <a href="/projects/ready-apps" className="bg-white text-black px-8 py-3 rounded-full font-bold hover:bg-gray-200 transition-colors">
                View Projects
              </a>
              <a href="/store" className="border border-white/30 bg-white/10 backdrop-blur-sm px-8 py-3 rounded-full font-bold hover:bg-white/20 transition-colors">
                Visit Store
              </a>
            </div>
          </div>
        </header>

        {/* Dummy Content Section */}
        <main className="max-w-7xl mx-auto px-4 py-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6">
               <h2 className="text-3xl font-bold border-b border-gray-800 pb-4">Implementation Notes</h2>
               <p className="text-gray-400 leading-relaxed">
                 To use this in Next.js App Router:
               </p>
               <ul className="list-disc pl-5 space-y-2 text-gray-400">
                 <li>Copy <code className="bg-gray-800 px-2 py-1 rounded text-pink-400">NavBar.tsx</code> to your components folder.</li>
                 <li>Ensure standard Tailwind configuration is present.</li>
                 <li>This component uses standard HTML <code className="bg-gray-800 px-2 py-1 rounded text-blue-400">&lt;a&gt;</code> tags. For client-side routing, replace with <code className="bg-gray-800 px-2 py-1 rounded text-yellow-400">Link</code> from <code className="bg-gray-800 px-2 py-1 rounded text-green-400">next/link</code>.</li>
                 <li>The video loops automatically and scales with the container height.</li>
               </ul>
            </div>
            <div className="bg-gray-800/50 p-8 rounded-2xl border border-gray-700">
              <h3 className="text-xl font-bold mb-4">Component Features</h3>
              <div className="space-y-4">
                <FeatureRow title="Video Background" status="Active" />
                <FeatureRow title="Mobile Hamburger" status="Responsive" />
                <FeatureRow title="Dropdown Menus" status="Animated" />
                <FeatureRow title="Accessibility" status="Aria-supported" />
                <FeatureRow title="Zero Dependencies" status="Pure React" />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

const FeatureRow = ({ title, status }: { title: string, status: string }) => (
  <div className="flex justify-between items-center border-b border-gray-700/50 pb-2 last:border-0">
    <span className="text-gray-300">{title}</span>
    <span className="text-xs font-mono bg-green-900/30 text-green-400 px-2 py-1 rounded">
      {status}
    </span>
  </div>
);

export default App;