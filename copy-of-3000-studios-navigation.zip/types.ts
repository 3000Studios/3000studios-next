export interface SubRoute {
  label: string;
  href: string;
  isExternal?: boolean;
}

export interface NavRoute {
  label: string;
  href: string;
  isExternal?: boolean;
  subRoutes?: SubRoute[];
}

export interface NavBarProps {
  backgroundVideoUrl?: string;
  className?: string;
}