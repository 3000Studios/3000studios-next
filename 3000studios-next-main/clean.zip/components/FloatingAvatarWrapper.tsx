'use client';
import ShadowAvatar from './ShadowAvatar';

export default function FloatingAvatarWrapper() {
  return <ShadowAvatar />;
}