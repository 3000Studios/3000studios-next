
export const AFFILIATES = {
  amazon: (asin:string) => `https://www.amazon.com/dp/${asin}?tag=YOURTAG`,
  software: (id:string) => `https://partner.site.com/?ref=3000studios&id=${id}`,
}
