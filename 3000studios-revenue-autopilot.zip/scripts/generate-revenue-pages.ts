
import fs from 'fs'
import path from 'path'

const pages = [
  { slug: 'best-ai-tools-for-creators', title: 'Best AI Tools for Creators (2025)', keywords: 'ai tools, creators, software' },
  { slug: 'best-passive-income-tools', title: 'Best Passive Income Tools', keywords: 'passive income, online tools' }
]

const template = (p:any) => `
export const metadata = { title: "${p.title}", description: "${p.keywords}" }
export default function Page() {
  return (<main><h1>${p.title}</h1><p>High-intent buyer content.</p></main>)
}`

pages.forEach(p => {
  const dir = path.join('src/app/revenue', p.slug)
  fs.mkdirSync(dir, { recursive: true })
  fs.writeFileSync(path.join(dir, 'page.tsx'), template(p))
})
