
fetch('https://www.google.com/ping?sitemap=https://3000studios.com/sitemap.xml')
