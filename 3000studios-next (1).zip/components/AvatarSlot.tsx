// 3D pipeline placeholder loader (no avatar model)
export default function AvatarSlot(){return null;}